/*************************************************************************************      
 *  ���� ���� �� : ������� ��������      
 *  ��   ��   �� : Ȳ �� ��      
 *  ��   ��   �� : 2022/12/01      
 *  ��   ��   �� :       
 *  ��   ��   �� :       
 *  ��        �� :       
 *  �� ��  �� �� :      
 *  �� ��  �� �� :      
 *  �� ��  �� �� :      
 exec PUT_MM_BIZ_AUTH_INQUIRY_TB_PROC '����', 'kafkatest', 'kafkatest@mediawill.com', '010-1234-5678' , 'sdjkfhslkdjfl.jpg', '��ϺҰ�Ȯ�ο��', '1'     
     
 *************************************************************************************/      
      
CREATE PROC [dbo].[PUT_MM_BIZ_AUTH_INQUIRY_TB_PROC]      
 @USER_NM             VARCHAR(50)    
  , @USER_ID    VARCHAR(50)    
  , @EMAIL               VARCHAR(50) = ''    
  , @HPHONE              VARCHAR(15)    
  , @INQUIRY_IMG         VARCHAR(100)    
  , @INQUIRY_CONTENTS    TEXT    
  , @STATUS              CHAR(1)     = '1'    
  , @MagID               VARCHAR(30)    
  , @CUID     VARCHAR(10)    
AS      
      
BEGIN      
      
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED      
  SET NOCOUNT ON      
    
  DECLARE @REAL_MAGID VARCHAR(50)    
  DECLARE @REAL_MAG_NM  VARCHAR(30)    
    
    
    
  IF @CUID <> @MagID     
  BEGIN    
     
 SET @REAL_MAGID = @MagID    
    
    SELECT @REAL_MAG_NM = MAGNAME FROM FINDDB2.FINDCOMMON.DBO.COMMONMAGUSER WITH (NOLOCK)    
    WHERE MagID = @MagID    
    
  END    
  ELSE    
  BEGIN    
    
 SET @REAL_MAGID = @USER_ID    
 SET @REAL_MAG_NM = @USER_NM    
    
  END    
    
    
  INSERT INTO [dbo].[BIZ_AUTH_INQUIRY_TB]    
    (    
  [USER_NM]    
    ,[USER_ID]    
    ,[EMAIL]    
    ,[HPHONE]    
    ,[INQUIRY_IMG]    
    ,[INQUIRY_CONTENTS]    
    ,[REG_DT]    
    ,[STATUS]    
  ,[INQUIRY_ID]    
  ,[INQUIRY_NM]    
  )    
  VALUES    
    (    
  @USER_NM    
    ,@USER_ID    
    ,@EMAIL    
    ,@HPHONE    
    ,@INQUIRY_IMG     
    ,@INQUIRY_CONTENTS     
    ,GETDATE()    
    ,@STATUS    
  ,@REAL_MAGID    
  ,@REAL_MAG_NM    
  )    
 END 