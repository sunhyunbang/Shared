      
/*************************************************************************************      
 *  ���� ���� �� : ���ΰ����� > �̷¼����� ��ǰ ����Ʈ      
 *  ��   ��   �� : �� �� ��      
 *  ��   ��   �� : 2015/02/16      
 *  ��   ��   �� : ������    
 *  ��   ��   �� : 2021-10-20     
 *  ��        �� : ������Ʈ ��ȸ�� ������ WR.adid_wills -> A.MWPLUS_ID�� ����      
 *  �� ��  �� �� :      
 *  �� ��  �� �� :      
 *  �� ��  �� �� :      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 25, '', '', '', '', 0, 0, 80, 0, '', '', '', '', ''      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 25, '1', '2015-02-16', '2015-02-16', '1', 0, 0, 90, 0, '', '', '', '', ''      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 25, '', '', '', '', 0, 0, 90, 0, '', '', '', '', ''      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 25, '', '', '', '', 0, 0, 80, 0, '2', '', '', '', ''      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 120, '0', '2015-02-06', '2015-03-06', '', 0, 0, 80, 0, '2', '', '', '', ''      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 10, '0', '2015-03-08', '2015-04-08', '', 0, 0, 80, 0, '', '', '2', '', ''      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 10, '0', '2015-03-09', '2015-04-09', '', 0, 0, 80, 0, '', '', '2', '', ''      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 10, '0', '2015-04-10', '2015-04-11', '2', 0, 0, 80, 0, '', '', '', '', ''      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 10, '0', '2015-03-09', '2015-04-09', '2', 01, 01, 80, 0, '', '', '', '', ''      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 10, '0', '2015-03-09', '2015-04-09', '1', 0, 0, 80, 0, '', '', '', '3', '(��)�̵������������'      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 10, '1', '2015-04-09', '2015-04-09', '2', 0, 0, 80, 0, '', '', '', '', ''      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 10, '0', '2015-03-15', '2015-04-15', '', 0, 0, 80, 0, '2', '', '', '', ''      
 EXEC GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC 1, 10, '0', '2015-04-01', '2015-06-12', '', 0, 0, 80, 0, '', '', '2', '8', '54664'      
 *************************************************************************************/      
CREATE PROC [dbo].[GET_M_RESUME_READ_GOODS_REGIST_LIST_PROC]      
  @PAGE                   INT               = 1      
, @PAGESIZE               INT               = 10      
, @DT_DIV                 CHAR(1)           = ''      
, @START_DT               VARCHAR(10)       = ''      
, @END_DT                 VARCHAR(10)       = ''      
, @ADGBN                  CHAR(1)           = ''      
, @SEARCH_MAG_AREA        TINYINT           = 0      
, @SEARCH_MAG_BRANCHCODE  TINYINT           = 0      
, @MAG_BRANCHCODE         TINYINT           = 0      
, @GOODS_ID               SMALLINT          = 0      
, @USED_GBN               CHAR(1)           = ''      
, @STATUS                 CHAR(1)           = ''      
, @PAY_STATUS             CHAR(1)           = ''      
, @SEARCH_KEY             CHAR(1)           = ''      
, @SEARCH_WORD            VARCHAR(50)       = ''      
AS      
      
BEGIN      
      
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED      
  SET NOCOUNT ON      
      
  DECLARE @SQL_COUNT NVARCHAR(4000)      
  DECLARE @SQL_SELECT NVARCHAR(4000)      
  DECLARE @SQL_WHERE NVARCHAR(4000)      
      
  SET @SQL_WHERE = ''      
      
      
  -- �Ⱓ����      
  IF @DT_DIV != ''      
  BEGIN      
    IF @DT_DIV = '0'          -- �����      
    BEGIN      
      IF @START_DT != '' AND @END_DT != ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND A.REG_DT >= ''' + @START_DT + ''' AND A.REG_DT < DATEADD(DAY, 1, ''' + @END_DT + ''') '      
      ELSE IF @START_DT != '' AND @END_DT = ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND A.REG_DT >= ''' + @START_DT + ''''      
      ELSE IF @START_DT = '' AND @END_DT != ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND A.REG_DT < DATEADD(DAY, 1, ''' + @END_DT + ''') '      
    END      
    ELSE IF @DT_DIV = '1'     -- ������      
    BEGIN      
      IF @START_DT != '' AND @END_DT != ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND A.START_DT >= ''' + @START_DT + ''' AND A.START_DT < DATEADD(DAY, 1, ''' + @END_DT + ''') '      
      ELSE IF @START_DT != '' AND @END_DT = ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND A.START_DT >= ''' + @START_DT + ''''      
      ELSE IF @START_DT = '' AND @END_DT != ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND A.START_DT < DATEADD(DAY, 1, ''' + @END_DT + ''') '      
    END      
    ELSE IF @DT_DIV = '2'     -- ������      
    BEGIN      
      IF @START_DT != '' AND @END_DT != ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND A.END_DT >= ''' + @START_DT + ''' AND A.END_DT < DATEADD(DAY, 1, ''' + @END_DT + ''') '      
      ELSE IF @START_DT != '' AND @END_DT = ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND A.END_DT >= ''' + @START_DT + ''''      
      ELSE IF @START_DT = '' AND @END_DT != ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND A.END_DT < DATEADD(DAY, 1, ''' + @END_DT + ''') '      
    END      
    ELSE IF @DT_DIV = '3'     -- ������      
    BEGIN      
      IF @START_DT != '' AND @END_DT != ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND D.RecDate >= ''' + @START_DT + ''' AND D.RecDate < DATEADD(DAY, 1, ''' + @END_DT + ''') '      
      ELSE IF @START_DT != '' AND @END_DT = ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND D.RecDate >= ''' + @START_DT + ''''      
      ELSE IF @START_DT = '' AND @END_DT != ''      
        SET @SQL_WHERE = @SQL_WHERE + ' AND D.RecDate < DATEADD(DAY, 1, ''' + @END_DT + ''') '      
    END      
  END      
      
  -- ��ϰ��      
  IF @ADGBN != ''      
    SET @SQL_WHERE = @SQL_WHERE + ' AND A.ADGBN = ''' + @ADGBN + ''''      
      
  IF @MAG_BRANCHCODE = '80'      
  BEGIN      
    IF @SEARCH_MAG_BRANCHCODE > 0      
      SET @SQL_WHERE = @SQL_WHERE + ' AND A.MAG_BRANCHCODE = ' + LTRIM(RTRIM(STR(@SEARCH_MAG_BRANCHCODE)))      
    ELSE IF @SEARCH_MAG_AREA != ''      
      SET @SQL_WHERE = @SQL_WHERE + ' AND A.MAG_AREA = ' + LTRIM(RTRIM(STR(@SEARCH_MAG_AREA)))      
  END      
      
  ELSE      
  BEGIN      
    IF @SEARCH_MAG_BRANCHCODE > 0      
      SET @SQL_WHERE = @SQL_WHERE + ' AND A.MAG_BRANCHCODE = ' + LTRIM(RTRIM(STR(@SEARCH_MAG_BRANCHCODE)))      
    ELSE      
      SET @SQL_WHERE = @SQL_WHERE + ' AND A.MAG_BRANCHCODE = ' + LTRIM(RTRIM(STR(@MAG_BRANCHCODE)))      
  END      
      
  -- ��ǰ����      
  IF @GOODS_ID > 0      
    SET @SQL_WHERE = @SQL_WHERE + ' AND A.GOODS_ID = ' + LTRIM(RTRIM(STR(@GOODS_ID)))      
      
  -- �̿����      
  IF @USED_GBN != ''      
  BEGIN      
    IF @USED_GBN = '1'        -- �̿���      
      SET @SQL_WHERE = @SQL_WHERE + ' AND ((A.START_DT > GETDATE() OR A.PAY_STATUS = 0) AND A.COMPULSION_YN = ''N'')'      
    ELSE IF @USED_GBN = '2'   -- �̿���      
      SET @SQL_WHERE = @SQL_WHERE + ' AND A.START_DT <= GETDATE() AND A.END_DT > DATEADD(DAY, -1, GETDATE()) AND A.COMPULSION_YN = ''N'' AND A.PAY_STATUS = 1 AND B.STATUS = 1 '      
    ELSE IF @USED_GBN = '3'   -- �̿�����      
      SET @SQL_WHERE = @SQL_WHERE + ' AND A.END_DT < DATEADD(DAY, -1, GETDATE()) AND A.COMPULSION_YN = ''N'' '      
    ELSE IF @USED_GBN = '4'      
      SET @SQL_WHERE = @SQL_WHERE + ' AND A.COMPULSION_YN = ''Y'' '      
  END      
      
  -- �ɻ����      
  IF @STATUS != ''      
  BEGIN      
    IF @STATUS = '2'      
      SET @SQL_WHERE = @SQL_WHERE + ' AND B.STATUS >= 2 '      
    ELSE      
      SET @SQL_WHERE = @SQL_WHERE + ' AND B.STATUS = ' + LTRIM(RTRIM(STR(@STATUS)))      
  END      
      
  -- ��������      
  IF @ADGBN = '' OR @ADGBN = '1'     -- ECOMM ��������      
  BEGIN      
    IF @PAY_STATUS != ''      
    BEGIN      
      IF @PAY_STATUS = '1'      -- �Ա���      
        SET @SQL_WHERE = @SQL_WHERE + ' AND D.ChargeKind = ''1'' AND D.PrnAmtOk = ''0'' '      
      ELSE IF @PAY_STATUS = '2' -- �����Ϸ�      
        SET @SQL_WHERE = @SQL_WHERE + ' AND ((A.ADGBN = 1 AND D.ChargeKind IS NOT NULL AND D.PrnAmtOk = ''1'') OR (A.ADGBN = 2)) '      
      ELSE IF @PAY_STATUS = '3' -- �����ߴ�      
        SET @SQL_WHERE = @SQL_WHERE + ' AND D.ChargeKind IN (''2'',''3'') AND RC.PrnAmtOk = ''0'' '      
      ELSE IF @PAY_STATUS = '4' -- �������      
        SET @SQL_WHERE = @SQL_WHERE + ' AND D.ChargeKind IS NOT NULL AND D.PrnAmtOk = ''2'' AND D.CancelDate IS NOT NULL '      
      ELSE IF @PAY_STATUS = '5' -- ��������      
        SET @SQL_WHERE = @SQL_WHERE + ' AND D.ChargeKind IS NULL '      
    END     
  END      
  ELSE IF @ADGBN = '2'                -- ��ϴ��� ��������      
  BEGIN      
    IF @PAY_STATUS != ''      
      SET @SQL_WHERE = @SQL_WHERE + ' AND A.CHARGE_KIND = ''' + @PAY_STATUS + ''''      
  END      
      
  -- Ű���� �˻�      
  IF @SEARCH_WORD != '' AND @SEARCH_KEY != ''      
  BEGIN      
    IF @SEARCH_KEY = '1'      -- USER_ID      
      --SET @SQL_WHERE = @SQL_WHERE + ' AND A.USER_ID LIKE ''' + @SEARCH_WORD + '%'' '    
   SET @SQL_WHERE = @SQL_WHERE + ' AND A.USER_ID = ''' + @SEARCH_WORD + ''' '      
    ELSE IF @SEARCH_KEY = '2' -- ��û��ȣ      
      SET @SQL_WHERE = @SQL_WHERE + ' AND A.REGIST_ID = ' + LTRIM(RTRIM(STR(@SEARCH_WORD)))      
    ELSE IF @SEARCH_KEY = '3' -- ��ȣ��      
      SET @SQL_WHERE = @SQL_WHERE + ' AND CIJ.COM_NM LIKE ''%' + @SEARCH_WORD + '%'' '      
    ELSE IF @SEARCH_KEY = '4' -- ��û ����ڸ�      
      --SET @SQL_WHERE = @SQL_WHERE + ' AND B.ONESNAME LIKE ''' + @SEARCH_WORD + '%'''    
   SET @SQL_WHERE = @SQL_WHERE + ' AND B.ONESNAME = ''' + @SEARCH_WORD + ''''      
    ELSE IF @SEARCH_KEY = '5' -- ��ȭ��ȣ(��û��)      
      --SET @SQL_WHERE = @SQL_WHERE + ' AND ((B.SEARCH_HPHONE LIKE ''' + REPLACE(@SEARCH_WORD, '-', '') + '%'') OR (B.SEARCH_PHONE LIKE ''' + REPLACE(@SEARCH_WORD, '-', '') + '%'')) '    
   SET @SQL_WHERE = @SQL_WHERE + ' AND ((B.SEARCH_HPHONE = ''' + REPLACE(@SEARCH_WORD, '-', '') + ''') OR (B.SEARCH_PHONE = ''' + REPLACE(@SEARCH_WORD, '-', '') + ''')) '      
    ELSE IF @SEARCH_KEY = '6' -- �̸���(��û��)      
      --SET @SQL_WHERE = @SQL_WHERE + ' AND B.EMAIL LIKE ''' + @SEARCH_WORD + '%'''    
   SET @SQL_WHERE = @SQL_WHERE + ' AND B.EMAIL = ''' + @SEARCH_WORD + ''''      
 ELSE IF @SEARCH_KEY = '7' -- ���������      
      SET @SQL_WHERE = @SQL_WHERE + ' AND A.REGIST_MAG_NAME = ''' + @SEARCH_WORD + ''''      
 ELSE IF @SEARCH_KEY = '8' -- ������Ʈ��ȣ WR.adid_wills -> A.MWPLUS_ID�� ����    
   SET @SQL_WHERE = @SQL_WHERE + ' AND A.MWPLUS_ID = ''' + @SEARCH_WORD + ''''      
  END      
      
  IF @PAGE = 1      
  BEGIN      
    SET @SQL_COUNT = '      
    SELECT COUNT(A.REGIST_ID) AS CNT      
      FROM PP_RESUME_READ_GOODS_REGIST_TB AS A (NOLOCK)      
      JOIN PP_RESUME_READ_GOODS_COMPANY_AUTH_TB AS B (NOLOCK) ON A.COMPANY_ID = B.COMPANY_ID      
      JOIN PP_RESUME_READ_GOODS_MASTER_TB AS E (NOLOCK) ON A.GOODS_ID = E.GOODS_ID      
      JOIN PP_COMPANY_INFO_JOB_VI AS CIJ ON B.CUID = CIJ.CUID      
      LEFT JOIN PP_ECOMM_RECCHARGE_TB AS D (NOLOCK) ON A.REGIST_ID = D.ADID AND D.PRODUCT_GBN = 6      
      LEFT JOIN FINDDB2.FINDCOMMON.dbo.CommonMagUser AS F (NOLOCK) ON A.MAG_ID = F.MagID      
      LEFT JOIN PP_AD_WILLS_RELATION_TB AS WR ON WR.adid_ppad = A.REGIST_ID AND WR.adType = 4      
      WHERE A.DEL_YN = ''N''      
        AND B.DEL_YN = ''N''     
     ' + @SQL_WHERE      
      
    PRINT @SQL_COUNT      
    EXECUTE SP_EXECUTESQL @SQL_COUNT      
  
  --  SELECT COUNT(A.REGIST_ID) AS CNT      
  --    FROM PP_RESUME_READ_GOODS_REGIST_TB AS A (NOLOCK)      
  --    JOIN PP_RESUME_READ_GOODS_COMPANY_AUTH_TB AS B (NOLOCK) ON A.COMPANY_ID = B.COMPANY_ID       
  -- LEFT JOIN PP_AD_WILLS_RELATION_TB AS WR ON WR.adid_ppad = A.REGIST_ID AND WR.adType = 4 '      
  --IF @SEARCH_KEY IN (3,7,8)            
  --    SET @SQL_COUNT = @SQL_COUNT + ' JOIN PP_COMPANY_INFO_JOB_VI AS CIJ ON B.CUID = CIJ.CUID '      
  --    SET @SQL_COUNT = @SQL_COUNT + 'LEFT JOIN PP_ECOMM_RECCHARGE_TB AS D (NOLOCK) ON A.REGIST_ID = D.ADID AND D.PRODUCT_GBN = 6       
  --   WHERE A.DEL_YN = ''N''      
  --     AND B.DEL_YN = ''N''      
  --   ' + @SQL_WHERE      
      
  --  --PRINT @SQL_COUNT      
  --  EXECUTE SP_EXECUTESQL @SQL_COUNT      
  END      
      
  SET @SQL_SELECT = '      
  SELECT X.REGIST_ID      
       , X.RecDate      
      , X.COM_NM      
       --,X.USER_ID    
    , dbo.FN_GET_USERID_SECURE(X.USER_ID) AS USER_ID    
       , X.START_DT      
       , X.END_DT      
       , X.COMPULSION_YN      
       , X.GOODS_NAME      
       , X.READ_CNT      
       , X.READ_REM_CNT      
       , X.SMS_CNT      
       , X.SMS_REM_CNT      
       , X.AD_PRICE      
       , X.COUPON_AMOUNT      
       , X.ADGBN      
       , X.MAG_AREA      
       , X.MAG_ID      
       , X.MAG_BRANCHCODE      
       , X.MagName      
       , X.PrnAmtOk      
       , X.ChargeKind      
       , X.CancelDate      
       , X.InipayTid      
       , X.CHARGE_KIND      
       , X.PAY_STATUS      
       , X.STATUS      
       , X.MWPLUS      
       , X.MWPLUS_ID      
    , X.REGIST_MAG_NAME      
       , X.ISSTORAGE      
       , X.WILLS_ADID      
    FROM (      
          SELECT ROW_NUMBER() OVER (ORDER BY A.REG_DT DESC) AS ROWNUM      
               , A.REGIST_ID      
               , CASE WHEN A.ADGBN = ''1'' THEN D.RecDate      
                      WHEN A.ADGBN = ''2'' THEN A.REG_DT      
                 END AS RECDATE      
               , CIJ.COM_NM      
               , B.USER_ID      
               , A.START_DT      
               , A.END_DT      
               , A.COMPULSION_YN      
               , E.GOODS_NAME      
               , A.READ_CNT      
               , A.READ_REM_CNT      
               , A.SMS_CNT      
               , A.SMS_REM_CNT      
               , A.AD_PRICE      
               , A.COUPON_AMOUNT      
               , A.ADGBN      
               , A.MAG_AREA      
               , A.MAG_ID      
               , A.MAG_BRANCHCODE      
               , F.MagName     
               , D.PrnAmtOk      
               , D.ChargeKind      
               , D.CancelDate      
               , D.InipayTid      
               , A.CHARGE_KIND      
               , A.PAY_STATUS      
               , B.STATUS      
               , A.MWPLUS      
               , A.MWPLUS_ID      
        , A.REGIST_MAG_NAME      
               , A.ISSTORAGE      
               , CASE WHEN WR.adid_ppad IS NULL THEN -1      
                                              ELSE ISNULL(A.MWPLUS_ID,0)      
                                              END      
                AS WILLS_ADID      
            FROM PP_RESUME_READ_GOODS_REGIST_TB AS A (NOLOCK)      
            JOIN PP_RESUME_READ_GOODS_COMPANY_AUTH_TB AS B (NOLOCK) ON A.COMPANY_ID = B.COMPANY_ID      
            JOIN PP_RESUME_READ_GOODS_MASTER_TB AS E (NOLOCK) ON A.GOODS_ID = E.GOODS_ID      
            JOIN PP_COMPANY_INFO_JOB_VI AS CIJ ON B.CUID = CIJ.CUID      
            LEFT JOIN PP_ECOMM_RECCHARGE_TB AS D (NOLOCK) ON A.REGIST_ID = D.ADID AND D.PRODUCT_GBN = 6      
            LEFT JOIN FINDDB2.FINDCOMMON.dbo.CommonMagUser AS F (NOLOCK) ON A.MAG_ID = F.MagID      
            LEFT JOIN PP_AD_WILLS_RELATION_TB AS WR ON WR.adid_ppad = A.REGIST_ID AND WR.adType = 4      
           WHERE A.DEL_YN = ''N''      
             AND B.DEL_YN = ''N''      
           ' + @SQL_WHERE + '      
         ) X      
   WHERE X.ROWNUM > ' + CONVERT(VARCHAR(10), (@PAGE - 1) * @PAGESIZE) + ' AND X.ROWNUM <= ' + CONVERT(VARCHAR(10), (@PAGE) * @PAGESIZE)      
      
  --PRINT @SQL_SELECT      
  EXECUTE SP_EXECUTESQL @SQL_SELECT      
END      
      