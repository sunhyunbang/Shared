/*************************************************************************************    
 *  ���� ���� �� : ����/����Ͻ� ȸ�� ����    
 *  ��   ��   �� : JMG    
 *  ��   ��   �� : 2016-08-17    
 *  ��   ��   �� : BJY    
 *  ��   ��   �� : 2021-09-02    
 *  ��        �� : 2021-09-02 -> �̿뵿�� ���� Ȯ���� ���� �������� �߰�    
 *  ��   ��   �� : BJY    
 *  ��   ��   �� : 2022-07-12    
 *  ��        �� : ���� �α��ν� REVOKE�� ���� �÷� �߰�    
 EXEC SP_MASTER_SELECT '13310360'    
 exec sp_master_select 13825469     
exec mwmember.dbo.sp_master_select 13818837    
exec MWMEMBER.dbo.SP_MASTER_SELECT 13822885    
    
exec MWMEMBER.dbo.SP_MASTER_SELECT 14221906    
    
 *************************************************************************************/    
    
CREATE PROCEDURE [dbo].[SP_MASTER_SELECT]    
    
 @CUID  int    
    
AS    
 SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED    
 SET NOCOUNT ON;    
 DECLARE @MEMBER_CD CHAR    
 DECLARE @CNT INT    
     
 SET @MEMBER_CD = ''    
 SET @CNT = 0    
     
 SELECT @MEMBER_CD = MEMBER_CD    
 FROM CST_MASTER WITH (NOLOCK)    
 WHERE CUID = @CUID AND OUT_YN = 'N'    
        
     create table #tb (cuid int null, s varchar(100) null, m varchar(100) null, t varchar(100) null, AGREE_DT datetime)    
     insert into #tb    
     SELECT CUID    
     ,MAX(CASE WHEN MEDIA_CD = 'S' THEN SECTION_CD ELSE '' END )  AS 'S'    
     ,MAX(CASE WHEN MEDIA_CD = 'M' THEN SECTION_CD ELSE '' END )  AS 'M'    
     ,MAX(CASE WHEN MEDIA_CD = 'T' THEN SECTION_CD ELSE '' END )  AS 'T'    
  ,MAX(AGREE_DT) AGREE_DT    
     FROM (    
     SELECT DISTINCT T.CUID,T.MEDIA_CD,    
     STUFF(( SELECT ',' + P.SECTION_CD    
     FROM CST_MSG_SECTION P WITH(NOLOCK)    
     WHERE (P.CUID = T.CUID AND P.MEDIA_CD = T.MEDIA_CD)    
     FOR XML PATH ('')),1,1,'') AS SECTION_CD    
     , AGREE_DT    
     FROM CST_MSG_SECTION T WITH(NOLOCK)    
     JOIN CST_MASTER CM WITH(NOLOCK) ON CM.CUID = T.CUID    
     WHERE CM.CUID = @CUID    
     ) S     
     GROUP BY CUID     
    
 IF @MEMBER_CD = '1'    
 BEGIN    
     SELECT CM.CUID, COM_ID, USERID, MEMBER_CD, USER_NM, HPHONE, EMAIL, GENDER, BIRTH, DI, CI, COM_ID    
     , ISNULL(S,'') SMS, ISNULL(M,'') MAIL, ISNULL(T,'') TM    
     , SNS_TYPE, SNS_ID    
     , case when CM.REALHP_YN ='Y' then 'Y'    
    when (SELECT COUNT(*) FROM CST_MASTER AS B WITH (NOLOCK) WHERE B.HPHONE = CM.HPHONE AND B.MEMBER_CD='1')  = 1  then 'Y' else 'N' end as REALHP_YN, '' MEMBER_TYPE    
  , t.AGREE_DT    
    , NULL AS SECTION_CD_ETC    
    , M.AGREE_DT AS MK_AGREE_DT    
    , ISNULL(M.AGREEF,0) AS MK_AGREEF    
   , CM.SITE_CD    
    , CASE ISNULL(CM.CI,'') WHEN '' THEN 0    
                                    ELSE 1    
                                    END AS CI_F    
  , (SELECT COUNT(*) FROM CST_SERVICE_USE_AGREE AS AG WITH(NOLOCK) WHERE AG.CUID = @CUID) AS SECTION_AGREE -- �̿뵿�� ���� 2021-09-02    
 , APPLE_REVOKE_TOKEN -- APPLE REFRESH_TOKEN    
     FROM CST_MASTER CM WITH (NOLOCK)    
     LEFT OUTER JOIN #tb t with(nolock) on t.cuid = CM.CUID    
      LEFT OUTER JOIN CST_MARKETING_AGREEF_TB AS M ON M.CUID = CM.CUID    
     WHERE CM.CUID = @CUID AND CM.OUT_YN = 'N' AND CM.MEMBER_CD = '1'    
         
 END    
     
 IF @MEMBER_CD = '2'    
 BEGIN    
     SELECT CM.CUID, CM.COM_ID, CM.USERID, MEMBER_CD, USER_NM, HPHONE, EMAIL, GENDER, BIRTH, DI, CI, CM.COM_ID    
     , CC.REGISTER_NO, CC.MAIN_PHONE, CC.PHONE, CC.COM_NM, CC.CEO_NM, CC.FAX, CC.HOMEPAGE, CC.LAT, CC.LNG, CC.CITY, CC.GU, CC.DONG, CC.ADDR1, CC.ADDR2, CC.LAW_DONGNO, CC.MAN_NO, CC.ROAD_ADDR_DETAIL    
     , ISNULL(CL.REG_NUMBER,'') REG_NUMBER, ISNULL(CA.MANAGER_NM,'') MANAGER_NM, ISNULL(CA.MANAGER_NUMBER,'') MANAGER_NUMBER, CM.SNS_TYPE, CM.SNS_ID    
     , ISNULL(S,'') SMS, ISNULL(M,'') MAIL, ISNULL(T,'') TM    
     , '' as REALHP_YN, CC.MEMBER_TYPE    
  , t.AGREE_DT    
    , CC.SECTION_CD_ETC    
    , M.AGREE_DT AS MK_AGREE_DT    
    , ISNULL(M.AGREEF,0) AS MK_AGREEF    
   , CM.SITE_CD    
    , CASE ISNULL(CM.CI,'') WHEN '' THEN 0    
                                    ELSE 1    
                                    END AS CI_F    
  , (SELECT COUNT(*) FROM CST_SERVICE_USE_AGREE AS AG WITH(NOLOCK) WHERE AG.CUID = @CUID) AS SECTION_AGREE -- �̿뵿�� ���� 2021-09-02    
  -- �귣��� ȸ�� ����    
  , BBT.CONFIRM_YN AS BRANCHCODE_CONFIRM_YN    
  , BBT.BR_SEQ    
  , APPLE_REVOKE_TOKEN -- APPLE REFRESH_TOKEN    
  , BBT.BRANCH_CODE AS BBCODE    
  , (SELECT COUNT(*) FROM CST_SERVICE_USE_AGREE AS AG WITH(NOLOCK) WHERE AG.CUID = @CUID AND SECTION_CD='S102') AS S102_SECTION_AGREE -- ���α��� �̿뵿�� ����     
  , CC.BIZLICENSE_CERTIFICATION_YN    
  , CC.BIZLICENSE_ISSUANCEDATE    
  , CC.BIZLICENSE_REGDATE  
  , CC.BIZ_CERTIFICATION_TYPE  
  , CC.BIZ_OPENDT  
     FROM CST_MASTER CM WITH(NOLOCK)    
     LEFT OUTER JOIN CST_COMPANY CC WITH(NOLOCK) ON CC.COM_ID = CM.COM_ID    
     LEFT OUTER JOIN #tb t with(nolock) on t.cuid = CM.CUID    
     LEFT OUTER JOIN CST_COMPANY_LAND CL WITH(NOLOCK) ON CL.COM_ID = CM.COM_ID    
     LEFT OUTER JOIN CST_COMPANY_AUTO CA WITH(NOLOCK) ON CA.COM_ID = CM.COM_ID         
  LEFT OUTER JOIN CST_MARKETING_AGREEF_TB AS M ON M.CUID = CM.CUID    
  LEFT OUTER JOIN PAPER_NEW.DBO.PP_BRAND_BRANCH_TB AS BBT WITH(NOLOCK) ON BBT.CUID = @CUID AND BBT.CANCEL_YN = 'N'    
     WHERE CM.CUID = @CUID AND CM.OUT_YN = 'N' AND CM.MEMBER_CD = '2'    
      
 END 