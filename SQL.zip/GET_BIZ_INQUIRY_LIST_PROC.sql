/*************************************************************************************        
 *  ���� ���� �� : ������� �������� ����Ʈ        
 *  ��   ��   �� : �� �� ��        
 *  ��   ��   �� : 2022/11/22        
 *  ��   ��   �� :        
 *  ��   ��   �� :        
 *  ��        �� :        
 *  �� ��  �� �� :        
 *  �� ��  �� �� :        
 *  �� ��  �� �� : EXEC GET_BIZ_INQUIRY_LIST_PROC '1','20','1','2022-10-01','2022-11-22','2','1','�����'      
       
*************************************************************************************/        
CREATE PROC [dbo].[GET_BIZ_INQUIRY_LIST_PROC]        
(        
  @PAGE INT = 1        
, @PAGESIZE INT = 10        
, @DATETYPE CHAR(1)    --�Ⱓ Ÿ�� (1:������, 2:ó����)        
, @STARTDATE VARCHAR(10) --������        
, @ENDTDATE VARCHAR(10)  --������        
, @STAUTS VARCHAR(1)   --ó������(0:��ü, 1:���, 2:����, 3:����)        
, @SEARCHTYPE VARCHAR(1) --�˻�Ÿ�� (1:������(USER_NM), 2:������ ID(INQUIRY_ID), 3:ó����(MAG_NM) )        
, @KEYWORD VARCHAR(100)   --�˻���        
)        
As        
SET NOCOUNT ON        
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED        
        
DECLARE @TableSQL1 nvarchar(3000) -- ���̺� ����1                                               
DECLARE @TableSQL2 nvarchar(3000) -- ���̺� ����2                                              
DECLARE @WhereSQL nvarchar(3000) -- �˻����� ����                                               
DECLARE @OrderSQL nvarchar(1000) -- ���� ����                                                
DECLARE @Params nvarchar(4000) -- ���� ���� ����        
        
----------------------------------------------------------------------------------------------------------------------------------------- �˻�����                                            
SET @WhereSQL = ''        
SET @OrderSQL = ''        
        
--������, ó���� �˻�        
IF @DATETYPE = '1'        
BEGIN        
  SET @WhereSQL = @WhereSQL + ' WHERE (ITB.REG_DT >= @STARTDATE AND ITB.REG_DT <= (@ENDTDATE + '' 23:59:59''))'        
  SET @OrderSQL = ' ORDER BY ITB.REG_DT DESC '        
END        
ELSE        
BEGIN        
  SET @WhereSQL = @WhereSQL + ' WHERE (ITB.APPORVAL_DATE >= @STARTDATE AND ITB.APPORVAL_DATE <= (@ENDTDATE + '' 23:59:59''))'        
  SET @OrderSQL = ' ORDER BY ITB.APPORVAL_DATE DESC '        
END        
        
-- ó������      
IF @STAUTS <> ''         
BEGIN      
 IF @STAUTS ='3'          
 BEGIN        
  SET @WhereSQL = @WhereSQL + ' AND ITB.STATUS IN(''3'',''4'',''5'',''6'') '        
 END        
 ELSE      
 BEGIN      
  SET @WhereSQL = @WhereSQL + ' AND ITB.STATUS = @STAUTS '      
 END      
END      
        
--�˻��� �˻� (1:������(INQUIRY_ID), 2:������ID (INQUIRY_ID), 3:ó����(MAG_NM) )        
IF @SEARCHTYPE <> '' AND @KEYWORD <> ''        
BEGIN        
  IF @SEARCHTYPE = '1' --������      
  BEGIN        
   SET @WhereSQL = @WhereSQL + ' AND ITB.INQUIRY_NM = @KEYWORD '        
  END        
  ELSE IF @SEARCHTYPE = '2' --������ID        
  BEGIN        
   SET @WhereSQL = @WhereSQL + ' AND ITB.INQUIRY_ID = @KEYWORD '        
  END        
  ELSE IF @SEARCHTYPE = '3' --ó����        
  BEGIN        
   SET @WhereSQL = @WhereSQL + ' AND ITB.MAG_NM = @KEYWORD '        
  END        
END        
        
SET @TableSQL1 = ' SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED '        
        
SET @TableSQL1 = @TableSQL1 + ' SELECT COUNT(ITB.IDX) AS CNT '                  
SET @TableSQL1 = @TableSQL1 + ' FROM BIZ_AUTH_INQUIRY_TB AS ITB '        
SET @TableSQL1 = @TableSQL1 + @WhereSQL        
        
SET @Params = '@PAGE INT        
, @PAGESIZE INT        
, @DATETYPE CHAR(1)      
, @STARTDATE VARCHAR(10)        
, @ENDTDATE VARCHAR(10)        
, @STAUTS VARCHAR(1)        
, @SEARCHTYPE VARCHAR(1)        
, @KEYWORD VARCHAR(100)'        
      
print 'COUNT : '+ @TableSQL1        
        
EXEC sp_executesql @TableSQL1, @Params        
, @PAGE = @PAGE        
, @PAGESIZE = @PAGESIZE        
, @DATETYPE = @DATETYPE      
, @STARTDATE = @STARTDATE        
, @ENDTDATE = @ENDTDATE        
, @STAUTS = @STAUTS        
, @SEARCHTYPE = @SEARCHTYPE        
, @KEYWORD = @KEYWORD        
        
SET @TableSQL2 = ' SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED '        
        
SET @TableSQL2 = @TableSQL2 + ' DECLARE @PAGE1 int, @PAGE2 int '        
SET @TableSQL2 = @TableSQL2 + ' Set @PAGE1 = (@PAGE-1) * @PAGESIZE + 1 '        
SET @TableSQL2 = @TableSQL2 + ' Set @PAGE2 = @PAGE * @PAGESIZE '        
        
SET @TableSQL2 = @TableSQL2 + ' SELECT TOP (@PAGESIZE) '        
SET @TableSQL2 = @TableSQL2 + '   A.IDX'        
SET @TableSQL2 = @TableSQL2 + '   , A.REG_DT'        
SET @TableSQL2 = @TableSQL2 + '   , A.USER_NM'        
SET @TableSQL2 = @TableSQL2 + '   , A.USER_ID'        
SET @TableSQL2 = @TableSQL2 + '   , A.INQUIRY_IMG'        
SET @TableSQL2 = @TableSQL2 + '   , A.MAG_NM'        
SET @TableSQL2 = @TableSQL2 + '   , A.STATUS'        
SET @TableSQL2 = @TableSQL2 + '   , A.APPORVAL_DATE'        
SET @TableSQL2 = @TableSQL2 + '   , dbo.FN_GET_USERID_SECURE(ISNULL(A.INQUIRY_ID,'''')) INQUIRY_ID'        
SET @TableSQL2 = @TableSQL2 + '   , A.INQUIRY_NM'        
SET @TableSQL2 = @TableSQL2 + ' FROM ( '        
SET @TableSQL2 = @TableSQL2 + '   SELECT TOP (@PAGE2) ROW_NUMBER() OVER(' + @OrderSQL + ') NUM '        
SET @TableSQL2 = @TableSQL2 + '     , ITB.IDX'        
SET @TableSQL2 = @TableSQL2 + '     , ITB.REG_DT'        
SET @TableSQL2 = @TableSQL2 + '     , ITB.USER_NM'        
SET @TableSQL2 = @TableSQL2 + '     , ITB.USER_ID'        
SET @TableSQL2 = @TableSQL2 + '     , ITB.INQUIRY_IMG'        
SET @TableSQL2 = @TableSQL2 + '     , ITB.MAG_NM'       
SET @TableSQL2 = @TableSQL2 + '     , ITB.STATUS'        
SET @TableSQL2 = @TableSQL2 + '     , ITB.APPORVAL_DATE'        
SET @TableSQL2 = @TableSQL2 + '     , ITB.INQUIRY_ID'        
SET @TableSQL2 = @TableSQL2 + '     , ITB.INQUIRY_NM'        
SET @TableSQL2 = @TableSQL2 + '   FROM BIZ_AUTH_INQUIRY_TB ITB '        
SET @TableSQL2 = @TableSQL2 + @WhereSQL        
SET @TableSQL2 = @TableSQL2 + ' ) A '        
SET @TableSQL2 = @TableSQL2 + ' WHERE A.Num Between @PAGE1 And @PAGE2 '        
        
print 'LIST : ' + @TableSQL2        
        
EXEC sp_executesql @TableSQL2, @Params        
, @PAGE = @PAGE        
, @PAGESIZE = @PAGESIZE        
, @DATETYPE = @DATETYPE      
, @STARTDATE = @STARTDATE        
, @ENDTDATE = @ENDTDATE        
, @STAUTS = @STAUTS        
, @SEARCHTYPE = @SEARCHTYPE        
, @KEYWORD = @KEYWORD 