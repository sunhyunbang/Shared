/*************************************************************************************    
 *  ���� ���� �� : ����ڵ���� �������� ������Ʈ    
 *  ��   ��   �� : �� �� ��    
 *  ��   ��   �� : 2022/11/04    
 *  ��   ��   �� :     
 *  ��   ��   �� :     
 *  ��        �� :     
 *  �� ��  �� �� :    
 *  �� ��  �� �� :    
 *  �� ��  �� �� :    
 exec PUT_MM_UPDATE_BIZLICENSE_PROC '2022-10-07 00:00:00','Y',14221906,'3ROLDG87ZL4TNA5RY5EN.jpg','AUTO','PC'  
 *************************************************************************************/    
    
CREATE PROC [dbo].[PUT_MM_UPDATE_BIZLICENSE_PROC]    
  @ISSUANCE_DATE     DATETIME    
, @CERTIFICATIO_YN   CHAR(1)    
, @CUID      INT    
, @BIZ_IMAGE    VARCHAR(50)    
, @HANDLE_ID    VARCHAR(30) = 'AUTO'   
, @BROWSER      VARCHAR(10) = 'PC'  
AS    
    
BEGIN    
    
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED    
  SET NOCOUNT ON    
      
  DECLARE @COM_ID     INT    
 DECLARE @CM_USERID  VARCHAR(50)  
  DECLARE @FINAL_MEMO   VARCHAR(100)  
  DECLARE @FINAL_MAGID  VARCHAR(30)  
  DECLARE @MAG_NM       VARCHAR(30)  
    
 SELECT   
 @COM_ID = COM_ID  
 ,@CM_USERID = USERID  
  ,@MAG_NM = USER_NM  
 FROM CST_MASTER WITH(NOLOCK)  
 WHERE CUID = @CUID  
 --AND MEMBER_CD = '2'  
  
  IF @HANDLE_ID <> 'AUTO' -- ���� ��Ͻ�  
  BEGIN  
   SET @FINAL_MEMO = 'Admin ���� ������� ���� -���� ����- �Ϸ�'  
    SET @FINAL_MAGID = @HANDLE_ID  
  END  
  ELSE -- ����Ʈ ��Ͻ�  
    SET @FINAL_MEMO = 'ȸ��(' + @CM_USERID + ')�� '+ @BROWSER +'���� ������� ���� -���� ����- �Ϸ�'  
    SET @FINAL_MAGID = @CM_USERID  
  END    
  
    
  IF @COM_ID IS NOT NULL AND @COM_ID <> ''    
  BEGIN    
    UPDATE A    
  SET A.BIZLICENSE_IMGNM = @BIZ_IMAGE    
  , A.BIZLICENSE_CERTIFICATION_YN = @CERTIFICATIO_YN    
  ,A.BIZLICENSE_ISSUANCEDATE = @ISSUANCE_DATE    
  ,A.BIZLICENSE_REGDATE = GETDATE()    
  ,A.BIZLICENSE_HANDLE_ID = @HANDLE_ID    
    ,A.BIZ_CERTIFICATION_TYPE = 'O'  
  FROM CST_COMPANY AS A    
  WHERE COM_ID = @COM_ID    
  
    IF (SELECT COUNT(MagID) FROM FINDDB2.FINDCOMMON.DBO.COMMONMAGUSER WITH (NOLOCK) WHERE MagID = @FINAL_MAGID) > 0  
    BEGIN  
      exec PUT_AD_MM_MEMBER_HISTORY_PROC @CUID ,@CM_USERID ,'S101' ,@FINAL_MAGID ,@FINAL_MEMO  
    END  
    ELSE  
    BEGIN  
      INSERT INTO [dbo].[MM_MEMBER_HISTORY_TB]  
            ([USERID]  
            ,[SECTION_CD]  
            ,[MAG_ID]  
            ,[MAG_NAME]  
            ,[MAG_BRANCH]  
            ,[COMMENT]  
            ,[REG_DT]  
            ,[CUID])  
      VALUES  
            (@CM_USERID  
            ,'S101'  
            ,@FINAL_MAGID  
            ,@MAG_NM  
            ,'80'  
            ,@FINAL_MEMO  
            ,GETDATE()  
            ,@CUID)  
      END  
  
  
 IF NOT EXISTS (SELECT CUID FROM PAPER_NEW.DBO.PP_RESUME_READ_GOODS_COMPANY_AUTH_TB WHERE CUID = @CUID)  
    BEGIN  
        -- ���  
        INSERT INTO PAPER_NEW.DBO.PP_RESUME_READ_GOODS_COMPANY_AUTH_TB (  
            ADGBN  
          , USER_ID  
          , BIZNO  
          , COM_NM  
          , EMAIL  
          , HPHONE  
          , SEARCH_HPHONE  
          , PHONE  
          , SEARCH_PHONE  
          , [STATUS]  
          , REJECT_COMMENT  
          , MAG_ID  
          , MAG_AREA  
          , MAG_BRANCHCODE  
          , CUID  
          , BIZ_IMAGE  
    , ONESNAME  
    , ONESDEPART  
    )  
    SELECT '1'  
   , CM.USERID  
   , CC.REGISTER_NO  
   , CC.COM_NM  
   , CM.EMAIL  
   , CC.MAIN_PHONE  
   , REPLACE(CC.MAIN_PHONE, '-', '')  
   , CC.PHONE  
   , REPLACE(CC.PHONE, '-', '')  
   , '1'  
   , ''  
   , @FINAL_MAGID  
   , '0'  
   , '0'  
   , @CUID  
   , @BIZ_IMAGE  
   , @MAG_NM  
   , ''  
   FROM CST_COMPANY AS CC WITH(NOLOCK)  
   JOIN CST_MASTER AS CM ON CC.COM_ID = CM.COM_ID   
   WHERE CC.COM_ID = @COM_ID  
   END  
  
  END    
  
  