/*************************************************************************************      
 *  ���� ���� �� : ���� ������ ��������      
 *  ��   ��   �� : �� �� ��      
 *  ��   ��   �� : 2022/11/30    
 *  ��        �� :      
 *  �� ��  �� �� :      
 *  �� ��  �� �� : EXEC GET_BIZ_AUTH_INQUIRY_DETAIL_PROC 2    
 *************************************************************************************/      
      
CREATE PROC [dbo].[GET_BIZ_AUTH_INQUIRY_DETAIL_PROC]      
  @IDX INT      
AS      
      
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED      
SET NOCOUNT ON      
      
SELECT     
BI.USER_NM    
,BI.USER_ID    
,BI.EMAIL    
,BI.HPHONE    
,BI.INQUIRY_IMG    
,BI.INQUIRY_CONTENTS    
,BI.REG_DT    
,BI.MAG_ID    
,BI.INQUIRY_ID  
,BI.INQUIRY_NM  
,ISNULL(BI.MAG_NM,'') AS MAG_NM    
,BI.STATUS    
,BI.STATUS_CONTENTS    
,BI.APPORVAL_DATE    
,BI.MEMO    
,ISNULL(CM.OUT_YN,'') AS OUT_YN    
,ISNULL(CM.REST_YN ,'') AS REST_YN    
,(CASE WHEN (SELECT COUNT(BD.IDX) CNT FROM BAD_DATA_TB BD WITH(NOLOCK) WHERE BD.USERID = CM.USERID AND (BD.DEL_YN IS NULL OR BD.DEL_YN <> 'Y')) > 0 THEN 'Y' ELSE 'N' END)  BAD_YN      
,CASE  WHEN ISNULL(CM.AGENCY_YN, 'N') = 'Y' THEN 'Y' ELSE 'N' END AS AGENCY_YN -- ȸ�����Դ��� ���� �߰�     
,ISNULL(CM.LAST_SIGNUP_YN, 'Y') AS LAST_SIGNUP_YN      
,ISNULL(CC.COM_NM,'') AS COM_NM    
,ISNULL(CC.REGISTER_NO,'') AS REGISTER_NO    
,ISNULL(CC.CEO_NM,'') AS CEO_NM    
FROM BIZ_AUTH_INQUIRY_TB AS BI WITH(NOLOCK)    
LEFT JOIN CST_MASTER AS CM WITH(NOLOCK) ON BI.USER_ID = CM.USERID    
LEFT JOIN CST_COMPANY AS CC WITH(NOLOCK) ON CM.COM_ID = CC.COM_ID    
WHERE IDX = @IDX 