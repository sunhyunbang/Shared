    
CREATE PROCEDURE [dbo].[SP_BIZLICENSE_AGREE_UPDATE]    
/*************************************************************************************    
 *  ���� ���� �� : ����ڵ���� ���������� ���/����   
 *  ��   ��   �� : �����    
 *  ��   ��   �� : 2022-11-09    
 *  ��   ��   �� :    
 *  ��   ��   �� :    
 *  ��        �� :     
 * RETURN(500)  -- ����    
 * RETURN(0) -- ����    
 * DECLARE @RET INT    
 *************************************************************************************/    
  @CUID int,    
  @COM_ID int ,    
  @USERID varchar(50),    
  @MAIN_PHONE varchar(14),    
  @FAX varchar(14) ,    
  @LAT decimal(16, 14) ,    
  @LNG decimal(17, 14) ,    
  @CITY varchar(50) ,    
  @GU varchar(50) ,    
  @DONG varchar(50) ,    
  @ADDR1 varchar(100) ,    
  @ADDR2 varchar(100) ,    
  @LAW_DONGNO char(10) ,    
  @MAN_NO varchar(25) ,    
  @ROAD_ADDR_DETAIL varchar(100),    
  @CEO_NM varchar(30)  ,  
  @COM_NM varchar(50)    
    
AS    
    
    SET NOCOUNT ON;    
    DECLARE @ID_COUNT bit    
  
    -- ������ üũ    
    SET @ID_COUNT = 0    
    
    SELECT @ID_COUNT = COUNT(COM_ID)     
      FROM CST_COMPANY WITH(NOLOCK)     
     WHERE COM_ID = @COM_ID    
    
   SET  @CITY = DBO.FN_AREA_A_SHORTNAME(@CITY)-- �ּ��� 2���ڷ� ����    
    
    IF @ID_COUNT = 1    
      BEGIN    
       UPDATE CST_COMPANY     
          SET MAIN_PHONE     = @MAIN_PHONE    
            ,CEO_NM = @CEO_NM    
            ,FAX      = @FAX    
            ,LAT      = @LAT    
            ,LNG      = @LNG    
            ,CITY      = @CITY    
            ,GU      = @GU    
            ,DONG      = @DONG    
            ,ADDR1      = @ADDR1    
            ,ADDR2      = @ADDR2    
            ,LAW_DONGNO     = @LAW_DONGNO    
            ,MAN_NO     = @MAN_NO    
            ,ROAD_ADDR_DETAIL   = @ROAD_ADDR_DETAIL    
            ,MOD_ID     = @USERID    
            ,MOD_DT     = GETDATE()    
      ,COM_NM     = @COM_NM  
  
      WHERE COM_ID = @COM_ID    
    
      INSERT INTO CST_COMPANY_HISTORY (COM_ID,COM_NM ,CEO_NM,MOD_ID, MOD_DT, MAIN_PHONE, PHONE, FAX, HOMEPAGE, LAT, LNG, CITY, GU,DONG, ADDR1, ADDR2, LAW_DONGNO, MAN_NO, ROAD_ADDR_DETAIL, CUID)     
          VALUES (@COM_ID,@COM_NM,@CEO_NM , @USERID, GETDATE(), @MAIN_PHONE, '', @FAX, '', @LAT, @LNG, @CITY, @GU,@DONG, @ADDR1, @ADDR2, @LAW_DONGNO, @MAN_NO, @ROAD_ADDR_DETAIL, @CUID)    
     
        RETURN(0) -- ����    
      END     
      
 ELSE    
      BEGIN    
        RETURN(500)  -- ����    
      END    
    